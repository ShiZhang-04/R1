import http from 'http';
import fs from 'fs';
import path from 'path';

const PORT = 3000;

function getDirectoryStructure(dir, ignoreList = ['node_modules', '.git', 'dist', '.npm']) {
  const stats = fs.statSync(dir);
  const info = {
    name: path.basename(dir),
    type: stats.isDirectory() ? 'directory' : 'file',
    path: dir
  };

  if (stats.isDirectory()) {
    info.children = fs.readdirSync(dir)
      .filter(child => !ignoreList.includes(child))
      .map(child => getDirectoryStructure(path.join(dir, child), ignoreList));
    
    // Sort: directories first, then files
    info.children.sort((a, b) => {
      if (a.type === b.type) return a.name.localeCompare(b.name);
      return a.type === 'directory' ? -1 : 1;
    });
  }

  return info;
}

const server = http.createServer((req, res) => {
  if (req.url === '/api/structure') {
    try {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      const structure = getDirectoryStructure(process.cwd());
      res.end(JSON.stringify(structure));
    } catch (e) {
      res.writeHead(500);
      res.end(JSON.stringify({ error: e.message }));
    }
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/html' });
  res.end(`
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Project Structure</title>
      <style>
        body {
          font-family: system-ui, -apple-system, sans-serif;
          background-color: #0f172a;
          color: #e2e8f0;
          margin: 0;
          padding: 2rem;
        }
        .container {
          max-width: 800px;
          margin: 0 auto;
          background: #1e293b;
          padding: 2rem;
          border-radius: 0.5rem;
          box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        }
        h1 { color: #38bdf8; margin-top: 0; margin-bottom: 0.5rem; }
        p { color: #94a3b8; margin-top: 0; margin-bottom: 1.5rem; }
        ul { list-style-type: none; padding-left: 1.5rem; border-left: 1px dashed #334155; margin-left: 0.5rem; }
        li { margin: 0.4rem 0; position: relative; }
        .folder { font-weight: 600; color: #fbbf24; cursor: pointer; user-select: none; display: flex; align-items: center; gap: 0.5rem; }
        .folder::before { content: '📁'; font-size: 1.1em; }
        .folder.open::before { content: '📂'; }
        .folder:hover { color: #fcd34d; }
        .file { color: #cbd5e1; display: flex; align-items: center; gap: 0.5rem; }
        .file::before { content: '📄'; font-size: 1.1em; opacity: 0.7; }
        .file.lua::before { content: '📜'; }
        .file.json::before { content: '📋'; }
        .file.rbxm::before { content: '📦'; }
        .file.md::before { content: '📝'; }
        .hidden { display: none; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Project Structure</h1>
        <p>Interactive view of your Rojo workspace.</p>
        <div id="tree">Loading...</div>
      </div>
      <script>
        function getFileClass(filename) {
          if (filename.endsWith('.lua')) return 'lua';
          if (filename.endsWith('.json')) return 'json';
          if (filename.endsWith('.rbxm') || filename.endsWith('.rbxlx')) return 'rbxm';
          if (filename.endsWith('.md')) return 'md';
          return '';
        }

        function createTree(node, isRoot = false) {
          if (node.type === 'file') {
            const li = document.createElement('li');
            li.className = 'file ' + getFileClass(node.name);
            li.textContent = node.name;
            return li;
          }

          const li = document.createElement('li');
          const span = document.createElement('span');
          span.className = 'folder open';
          span.textContent = node.name;
          
          const ul = document.createElement('ul');
          if (isRoot) ul.style.borderLeft = 'none'; // Remove line for root
          
          node.children.forEach(child => {
            ul.appendChild(createTree(child));
          });

          span.onclick = (e) => {
            e.stopPropagation();
            ul.classList.toggle('hidden');
            span.classList.toggle('open');
          };

          li.appendChild(span);
          li.appendChild(ul);
          return li;
        }

        fetch('/api/structure')
          .then(res => res.json())
          .then(data => {
            const tree = document.getElementById('tree');
            tree.innerHTML = '';
            const ul = document.createElement('ul');
            ul.style.paddingLeft = '0';
            ul.style.borderLeft = 'none';
            ul.appendChild(createTree(data, true));
            tree.appendChild(ul);
          })
          .catch(err => {
            document.getElementById('tree').textContent = 'Error loading structure.';
          });
      </script>
    </body>
    </html>
  `);
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(\`Structure shower active on port \${PORT}\`);
});
