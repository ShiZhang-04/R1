local Players = game:GetService("Players")
local DataStoreService = game:GetService("DataStoreService")
local RunService = game:GetService("RunService")

local PlayerDataStore = DataStoreService:GetDataStore("WaterTycoon_SaveData_V1")

-- Create a container for player bases
local basesFolder = workspace:FindFirstChild("PlayerBases")
if not basesFolder then
    basesFolder = Instance.new("Folder")
    basesFolder.Name = "PlayerBases"
    basesFolder.Parent = workspace
end

-- Function to spawn an item from save data
local function spawnSavedItem(player, itemData)
    local itemType = itemData.Type
    local pos = Vector3.new(itemData.X, itemData.Y, itemData.Z)
    
    local model = nil
    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    
    -- Try to find the actual model in ReplicatedStorage or ServerStorage
    local sourceModel = nil
    if itemType == "Tank" then
        sourceModel = ReplicatedStorage:FindFirstChild("Tank") or workspace:FindFirstChild("Tank")
    elseif itemType == "Plot" then
        sourceModel = ReplicatedStorage:FindFirstChild("PlantSoil") or workspace:FindFirstChild("PlantSoil")
        if sourceModel then
            sourceModel.Name = "PlantPlot"
        end
    end
    
    if sourceModel and sourceModel:IsA("Model") then
        model = sourceModel:Clone()
        
        -- Make sure it has a PrimaryPart for positioning
        if not model.PrimaryPart then
            if itemType == "Tank" then
                model.PrimaryPart = model:FindFirstChild("TankBody")
            elseif itemType == "Plot" then
                model.PrimaryPart = model:FindFirstChild("Soil")
            end
        end
        
        if model.PrimaryPart then
            model:SetPrimaryPartCFrame(CFrame.new(pos))
        else
            model:MoveTo(pos)
        end
    else
        -- Fallback to basic blocks if models aren't found
        warn("Could not find source model for " .. itemType .. " during load, using fallback blocks")
        if itemType == "Tank" then
            model = Instance.new("Model")
            model.Name = "Tank"
            local body = Instance.new("Part")
            body.Name = "TankBody"
            body.Size = Vector3.new(6,8,6)
            body.Anchored = true
            body.Position = pos
            body.Parent = model
            model.PrimaryPart = body
        elseif itemType == "Plot" then
            model = Instance.new("Model")
            model.Name = "PlantPlot"
            local soil = Instance.new("Part")
            soil.Name = "Soil"
            soil.Size = Vector3.new(4,0.5,4)
            soil.Anchored = true
            soil.Position = pos
            soil.Parent = model
            model.PrimaryPart = soil
            local plant = Instance.new("Part")
            plant.Name = "Plant"
            plant.Size = Vector3.new(0.5,0.5,0.5)
            plant.Anchored = true
            plant.Position = soil.Position + Vector3.new(0, soil.Size.Y/2 + 0.25, 0)
            plant.Parent = model
        end
    end

    if model then
        model:SetAttribute("ItemType", itemType)
        model:SetAttribute("OwnerId", player.UserId)
        
        local playerBase = basesFolder:FindFirstChild(tostring(player.UserId))
        if not playerBase then
            playerBase = Instance.new("Folder")
            playerBase.Name = tostring(player.UserId)
            playerBase.Parent = basesFolder
        end
        
        model.Parent = playerBase
        
        -- If it's a tank, we need to set it up so it works
        if itemType == "Tank" then
            -- We need to call setupTank from MainGameSystems, but since we can't easily access it here,
            -- we'll just let the auto-setup loop in MainGameSystems catch it, or we can fire a bindable event.
            -- For now, the DescendantAdded event in MainGameSystems should catch this when it's parented to workspace.
        end
    end
end

Players.PlayerAdded:Connect(function(player)
    -- Wait for Leaderstats to be created by Leaderstats.server.lua
    local ls = player:WaitForChild("leaderstats", 10)
    if not ls then
        warn("Leaderstats not found for " .. player.Name)
        return
    end

    local water = ls:WaitForChild("Water")
    local money = ls:WaitForChild("Money")
    local seeds = ls:WaitForChild("Seeds")

    -- 2. Create Base Folder
    local playerBase = Instance.new("Folder")
    playerBase.Name = tostring(player.UserId)
    playerBase.Parent = basesFolder

    -- 3. Load Data
    local success, data = pcall(function()
        return PlayerDataStore:GetAsync(tostring(player.UserId))
    end)

    if success and data then
        print("Loaded data for " .. player.Name)
        if data.Stats then
            water.Value = data.Stats.Water or 2
            money.Value = data.Stats.Money or 0
            seeds.Value = data.Stats.Seeds or 0
        end
        
        if data.Items then
            for _, itemData in ipairs(data.Items) do
                spawnSavedItem(player, itemData)
            end
        end
    else
        print("No save data found for " .. player.Name .. " or failed to load.")
    end
end)

local savingPlayers = {}
local function savePlayerData(player)
    if savingPlayers[player.UserId] then return end
    savingPlayers[player.UserId] = true

    if not player:FindFirstChild("leaderstats") then 
        savingPlayers[player.UserId] = nil
        return 
    end
    
    local data = {
        Stats = {
            Water = player.leaderstats.Water.Value,
            Money = player.leaderstats.Money.Value,
            Seeds = player.leaderstats.Seeds.Value
        },
        Items = {}
    }
    
    local playerBase = basesFolder:FindFirstChild(tostring(player.UserId))
    if playerBase then
        for _, item in ipairs(playerBase:GetChildren()) do
            local itemType = item:GetAttribute("ItemType")
            local primaryPart = item.PrimaryPart or item:FindFirstChildWhichIsA("BasePart")
            if itemType and primaryPart then
                table.insert(data.Items, {
                    Type = itemType,
                    X = primaryPart.Position.X,
                    Y = primaryPart.Position.Y,
                    Z = primaryPart.Position.Z
                })
            end
        end
    end
    
    local success, err = pcall(function()
        PlayerDataStore:SetAsync(tostring(player.UserId), data)
    end)
    
    if success then
        print("Saved data for " .. player.Name)
    else
        warn("Failed to save data for " .. player.Name .. ": " .. tostring(err))
    end
    
    savingPlayers[player.UserId] = nil
end

Players.PlayerRemoving:Connect(function(player)
    savePlayerData(player)
    
    -- Cleanup base
    local playerBase = basesFolder:FindFirstChild(tostring(player.UserId))
    if playerBase then
        playerBase:Destroy()
    end
end)

game:BindToClose(function()
    for _, player in ipairs(Players:GetPlayers()) do
        task.spawn(function()
            savePlayerData(player)
        end)
    end
    if RunService:IsStudio() then
        task.wait(3) -- Hold server open to ensure DataStore requests finish before Studio kills the test
    end
end)
