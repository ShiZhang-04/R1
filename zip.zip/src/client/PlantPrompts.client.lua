-- src/client/PlantPrompts.client.lua
-- No auto-creation anymore - only binds to prompts you manually placed

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")

local player = Players.LocalPlayer

local PlantEvent     = ReplicatedStorage:WaitForChild("PlantEvent", 10)
local OpenShopEvent  = ReplicatedStorage:WaitForChild("OpenShopEvent", 10)
local BuyItemEvent   = ReplicatedStorage:WaitForChild("BuyItemEvent", 10)
local PlaceItemEvent = ReplicatedStorage:WaitForChild("PlaceItemEvent", 10)

-- Bind existing prompts (manual only)
local function bindPrompt(prompt)
    if prompt.Parent and prompt.Parent.Name == "Soil" then
        prompt.Triggered:Connect(function()
            local plot = prompt.Parent.Parent  -- Soil → PlantPlot
            PlantEvent:FireServer(plot)
        end)
    end
end

-- Initial scan
for _, desc in workspace:GetDescendants() do
    if desc:IsA("ProximityPrompt") then
        bindPrompt(desc)
    end
end

-- New prompts added later
workspace.DescendantAdded:Connect(function(desc)
    if desc:IsA("ProximityPrompt") then
        bindPrompt(desc)
    end
end)

-- Shop GUI handling
OpenShopEvent.OnClientEvent:Connect(function()
    local gui = player.PlayerGui:FindFirstChild("ShopGui")
    if gui then
        gui.Enabled = true
    end
end)

-- Connect shop buttons (manual names)
task.spawn(function()
    local gui = player.PlayerGui:WaitForChild("ShopGui", 15)
    if not gui then return end

    local frame = gui:FindFirstChild("Frame") or gui  -- adjust if no Frame
    local buyTankBtn = frame:FindFirstChild("BuyTank")
    local buyPlotBtn = frame:FindFirstChild("BuyPlot")
    local buySeedBtn = frame:FindFirstChild("BuySeed")
    local closeBtn   = frame:FindFirstChild("Close")

    if buyTankBtn then
        buyTankBtn.MouseButton1Click:Connect(function()
            BuyItemEvent:FireServer("Tank")
        end)
    end
    if buyPlotBtn then
        buyPlotBtn.MouseButton1Click:Connect(function()
            BuyItemEvent:FireServer("Plot")
        end)
    end
    if buySeedBtn then
        buySeedBtn.MouseButton1Click:Connect(function()
            BuyItemEvent:FireServer("Seed")
        end)
    end
    if closeBtn then
        closeBtn.MouseButton1Click:Connect(function()
            gui.Enabled = false
        end)
    end
end)

-- Placement tool logic
task.spawn(function()
    player:WaitForChild("Backpack", 10)
    
    local mouse = player:GetMouse()
    local currentPreview = nil
    local currentTool = nil
    local connection = nil
    
    local function clearPreview()
        if currentPreview then
            currentPreview:Destroy()
            currentPreview = nil
        end
        if connection then
            connection:Disconnect()
            connection = nil
        end
    end

    local function createPreview(itemType)
        clearPreview()
        
        currentPreview = Instance.new("Model")
        currentPreview.Name = "Preview"
        
        local part = Instance.new("Part")
        part.Anchored = true
        part.CanCollide = false
        part.Transparency = 0.5
        part.Material = Enum.Material.Neon
        part.Color = Color3.new(0, 1, 0)
        
        if itemType == "Tank" then
            part.Size = Vector3.new(6, 8, 6)
        elseif itemType == "Plot" then
            part.Size = Vector3.new(4, 0.5, 4)
        end
        
        part.Parent = currentPreview
        currentPreview.PrimaryPart = part
        currentPreview.Parent = workspace
        
        connection = RunService.RenderStepped:Connect(function()
            if currentPreview and currentPreview.PrimaryPart and mouse.Hit then
                -- Snap to grid (optional, but good for bases)
                local pos = mouse.Hit.Position
                local snappedY = pos.Y + (part.Size.Y / 2)
                currentPreview:SetPrimaryPartCFrame(CFrame.new(pos.X, snappedY, pos.Z))
            end
        end)
    end

    player.CharacterAdded:Connect(function(char)
        char.ChildAdded:Connect(function(tool)
            if tool:IsA("Tool") and (tool.Name == "TankPlacer" or tool.Name == "PlotPlacer") then
                currentTool = tool
                local itemType = tool.Name:gsub("Placer", "")
                createPreview(itemType)
                
                tool.Activated:Connect(function()
                    if currentPreview and currentPreview.PrimaryPart then
                        local pos = currentPreview.PrimaryPart.Position
                        -- Send the bottom-center position so the server spawns it correctly
                        local spawnPos = pos - Vector3.new(0, currentPreview.PrimaryPart.Size.Y / 2, 0)
                        PlaceItemEvent:FireServer(itemType, spawnPos)
                        clearPreview()
                        tool:Destroy()
                    end
                end)
            end
        end)
        
        char.ChildRemoved:Connect(function(tool)
            if tool == currentTool then
                clearPreview()
                currentTool = nil
            end
        end)
    end)
end)

print("PlantPrompts loaded - only binding existing prompts")